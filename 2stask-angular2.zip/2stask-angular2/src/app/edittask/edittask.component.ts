import { Component, OnInit } from '@angular/core';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';

import { TaskService } from '../task.service';
import { Task } from '../task';
import { Layer } from '../layer';
import { Project } from '../project';
import { Status } from '../task_status';

import { ActivatedRoute, ParamMap } from '@angular/router';
import 'rxjs/add/operator/switchMap';


@Component({
  selector: 'app-edittask',
  templateUrl: './edittask.component.html',
  styleUrls: ['./edittask.component.css']
})
export class EdittaskComponent implements OnInit {

  taskForm: FormGroup;
  statusCode: number;
  task: Task[];
  allLayers: Layer[];
  allProjects: Project[];
  allStatus: Status[];

  taskIdToUpdate = null;
  taskname: String;
  comments: String;
  startdate: Date;

  constructor(
    private taskService: TaskService,
    private fb: FormBuilder,
    private route: ActivatedRoute
  ) {

    this.taskForm = fb.group({
      'idtask': [null, Validators.required],
      'idproject': [null, Validators.required],
      'taskname': [null, Validators.required],
      'idlayer': [null, Validators.required],
      'idtaskstatus': [null, Validators.required],
      'comments': '',
      'startdate': [null, Validators.required],
    });

  }

  ngOnInit() {
    this.getLayers();
    this.getProjects();
    this.getStatus();
    this.loadTaskToEdit();
  }

  getLayers() {
    this.taskService.getLayers()
      .subscribe(
      data => this.allLayers = data,
      errorCode => this.statusCode = errorCode);
  }

  getProjects() {
    this.taskService.getProjects()
      .subscribe(
      data => this.allProjects = data,
      errorCode => this.statusCode = errorCode);
  }

  getStatus() {
    this.taskService.getStatus()
      .subscribe(
      data => this.allStatus = data,
      errorCode => this.statusCode = errorCode);
  }
  loadTaskToEdit() {
    this.route.paramMap
      .switchMap((params: ParamMap) => this.taskService.getTaskById(+params.get('idtask')))
      .subscribe(task => {
        this.taskForm.setValue({
          idtask: task.idtask,
          idproject: task.idproject,
          idlayer: task.idlayer,
          taskname: task.taskname,
          idtaskstatus: task.idtaskstatus,
          comments: task.comments,
          startdate: task.startdate
        });
      },
      errorCode => this.statusCode = errorCode);
  }



  //Handle create and update task
  onTaskFormSubmit() {
    let idtask = this.taskForm.controls['idtask'].value;
    let taskname = this.taskForm.controls['taskname'].value;
    let idlayer = this.taskForm.controls['idlayer'].value;
    let idproject = this.taskForm.controls['idproject'].value;
    let startdate = this.taskForm.controls['startdate'].value;
    let idtaskstatus = this.taskForm.controls['idtaskstatus'].value;
    let comments = this.taskForm.controls['comments'].value;

    let task = new Task(idtask, idproject, taskname, '9', idlayer, idtaskstatus, comments, startdate, '9');

    this.taskService.updateTask(task)
      .subscribe(successCode => {
        this.statusCode = successCode;
      },
      errorCode => this.statusCode = errorCode);
  }
}
