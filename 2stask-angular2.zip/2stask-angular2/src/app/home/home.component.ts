import { Component, OnInit } from '@angular/core';

import {Inject} from '@angular/core';
import {MatDialog, MAT_DIALOG_DATA} from '@angular/material';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit {

  title: string = '2Stask';
  links: Array<{ path: string, label: string }>;

  constructor(public dialog: MatDialog) {
    this.links = [
      { path: '/ongoingtasks', label: 'Ongoing' },
      { path: '/createtask', label: 'Onhold' },
      { path: '/home', label: 'All' }
    ]
  }

  ngOnInit() {
  }

  openDialog() {
    this.dialog.open(DialogDataExampleDialog, {
      data: {
        animal: 'lion'
      }
    });
  }
  
}

@Component({
  selector: 'dialog-data-example-dialog',
  templateUrl: 'dialog-data-example-dialog.html',
})

export class DialogDataExampleDialog {
  constructor(@Inject(MAT_DIALOG_DATA) public data: any) {}
}