import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { TaskService } from '../task.service';
import { Task } from '../task';

@Component({
  selector: 'app-ongoingtasks',
  templateUrl: './ongoingtasks.component.html',
  styleUrls: ['./ongoingtasks.component.css']
})
export class OngoingtasksComponent implements OnInit {
  //Component properties
  allOngoingTasks: Task[];
  statusCode: number;
  requestProcessing = false;
  taskIdToUpdate = null;
    
  //Create constructor to get service instance
  constructor(private taskService: TaskService) { }

  ngOnInit(): void {
    this.getOngoingTasks();
  }   

  //Fetch all ongoing tasks
  getOngoingTasks() {
    this.taskService.getOngoingTasks()
  .subscribe(
            data => this.allOngoingTasks = data,
            errorCode =>  this.statusCode = errorCode);   
    }

}

