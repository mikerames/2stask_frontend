import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HomeComponent } from './home/home.component';
import { OngoingtasksComponent } from './ongoingtasks/ongoingtasks.component';
import { OnholdtasksComponent } from './onholdtasks/onholdtasks.component';
import { CreatetaskComponent } from './createtask/createtask.component';
import { TaskComponent } from './task.component';
import { TaskService } from './task.service';
import { EdittaskComponent } from './edittask/edittask.component';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {NoopAnimationsModule} from '@angular/platform-browser/animations';
import {MatButtonModule, MatCheckboxModule} from '@angular/material';
import {MatTabsModule} from '@angular/material/tabs';
import {MatDialogModule} from '@angular/material/dialog';
import {DialogData} from './home/home.component';

@NgModule({
  declarations: [
    AppComponent,
    OngoingtasksComponent,
    OnholdtasksComponent,
    TaskComponent,
    CreatetaskComponent,
    HomeComponent,
    EdittaskComponent,
    DialogData
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    NoopAnimationsModule,
    MatButtonModule, 
    MatCheckboxModule,
    MatTabsModule,
    MatDialogModule
  ],
  exports: [MatButtonModule, MatCheckboxModule],
  entryComponents: [
    DialogData
  ],
  providers: [
  	TaskService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
