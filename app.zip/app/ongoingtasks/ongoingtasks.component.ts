import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { TaskService } from '../task.service';
import { Task } from '../task';

import { Inject } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-ongoingtasks',
  templateUrl: './ongoingtasks.component.html',
  styleUrls: ['./ongoingtasks.component.css']
})
export class OngoingtasksComponent implements OnInit {
  //Component properties
  allOngoingTasks: Task[];
  statusCode: number;
  requestProcessing = false;
  taskIdToUpdate = null;

  //Create constructor to get service instance
  constructor(private taskService: TaskService, public dialog: MatDialog) { }

  ngOnInit(): void {
    this.getOngoingTasks();
  }

  //Fetch all ongoing tasks
  getOngoingTasks() {
    this.taskService.getOngoingTasks()
      .subscribe(
      data => this.allOngoingTasks = data,
      errorCode => this.statusCode = errorCode);
  }

  //Delete task
  deleteTask(idtask: string) {
    if (confirm("Do you confirm task " + idtask + " should be deleted?")) {
      this.taskService.deleteTaskById(idtask)
        .subscribe(successCode => {
          this.statusCode = successCode;
          this.getOngoingTasks();
        },
        errorCode => this.statusCode = errorCode);
    }
  }


  openDialog() {
    this.dialog.open(DialogConfirm, {
      data: {
        animal: 'lion'
      }
    });
  }

}

/*Invokes Dialog component to present the app-createtask component in it.
Instead of having a dedicated templateUrl for each dialog, we directly use here Angular Materials.
*/
@Component({
  selector: 'dialog-data',
  template: `
    <div mat-dialog-content style="transform: none;opacity: 1;padding-left: 0px;padding-right: 0px;">
      <app-ongoingtasks></app-ongoingtasks>      
    </div>
  `
})

export class DialogConfirm {
  constructor( @Inject(MAT_DIALOG_DATA) public data: any) { }
}
