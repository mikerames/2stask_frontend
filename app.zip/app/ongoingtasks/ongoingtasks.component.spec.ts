import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {} from 'jasmine';
import { OngoingtasksComponent } from './ongoingtasks.component';

describe('OngoingtasksComponent', () => {
  let component: OngoingtasksComponent;
  let fixture: ComponentFixture<OngoingtasksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OngoingtasksComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OngoingtasksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
