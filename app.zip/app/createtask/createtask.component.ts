import { Component, OnInit } from '@angular/core';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';

import { TaskService } from '../task.service';
import { Task } from '../task';
import { Layer } from '../layer';
import { Project } from '../project';
import { Status } from '../task_status';

@Component({
  selector: 'app-createtask',
  templateUrl: './createtask.component.html',
  styleUrls: ['./createtask.component.css']
})
export class CreatetaskComponent implements OnInit {

  taskForm: FormGroup;
  post: any;
  allLayers: Layer[];
  allProjects: Project[];
  allStatus: Status[];
  statusCode: number;
  titleAlert: string = 'This field is required';

  //Task variables to be assigned
  idtask: number;
  idproject: number;
  taskname: string;
  assignee_uid: string;
  idlayer: number;
  idtaskstatus: number;
  comments: string;
  startdate: string;
  enddate: string;

  constructor(
    private taskService: TaskService,
    private fb: FormBuilder
  ) {
    this.taskForm = fb.group({
      'taskname': [null, Validators.required],
      'idlayer': [null, Validators.required],
      'idproject': [null, Validators.required],
      'startdate': [null, Validators.required],
      'idtaskstatus': [null, Validators.required],
      'comments': ''
    });
  }

  ngOnInit(): void {
    this.getLayers();
    this.getProjects();
    this.getStatus();
  }

  getLayers() {
    this.taskService.getLayers()
      .subscribe(
      data => this.allLayers = data,
      errorCode => this.statusCode = errorCode);
  }

  getProjects() {
    this.taskService.getProjects()
      .subscribe(
      data => this.allProjects = data,
      errorCode => this.statusCode = errorCode);
  }

  getStatus() {
    this.taskService.getStatus()
      .subscribe(
      data => this.allStatus = data,
      errorCode => this.statusCode = errorCode);
  }

  //Handle create task
  onTaskFormSubmit(post) {
    this.idtask = post.idtask;
    this.idproject = post.idproject;
    this.taskname = post.taskname;
    this.idlayer = post.idlayer;
    this.idtaskstatus = post.idtaskstatus;
    this.comments = post.comments;
    this.startdate = post.startdate;
    this.enddate = post.startdate;

    let task = new Task(this.idtask, this.idproject, this.taskname, this.assignee_uid, this.idlayer, this.idtaskstatus, this.comments, this.startdate, this.enddate);

    this.taskService.createTask(task)
      .subscribe(successCode => {
        this.statusCode = successCode;
      },
      errorCode => this.statusCode = errorCode);
  }

}