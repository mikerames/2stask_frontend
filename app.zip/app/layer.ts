export class Layer {
	constructor(
	public idlayer: number,
	public layer: string
	) {
	}
}