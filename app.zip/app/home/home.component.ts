import { Component, OnInit } from '@angular/core';

import { Inject } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit {

  title: string = '2Stask';
  links: Array<{ path: string, label: string }>;

  constructor(public dialog: MatDialog) {
    this.links = [
      { path: '/ongoingtasks', label: 'Ongoing' },
      { path: '/createtask', label: 'Onhold' },
      { path: '/home', label: 'All' }
    ]
  }

  ngOnInit() {
  }

  openDialog() {
    this.dialog.open(DialogData, {
      data: {
        animal: 'lion'
      }
    });
  }

}

/*Invokes Dialog component to present the app-createtask component in it.
Instead of having a dedicated templateUrl for each dialog, we directly use here Angular Materials.
*/
@Component({
  selector: 'dialog-data',
  template: `
    <div mat-dialog-content style="transform: none;opacity: 1;padding-left: 0px;padding-right: 0px;">
      <app-createtask></app-createtask>
    </div>
  `
})
export class DialogData {
  constructor( @Inject(MAT_DIALOG_DATA) public data: any) { }
}