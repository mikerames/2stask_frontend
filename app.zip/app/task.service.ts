import { Injectable } from '@angular/core';
import { Http, Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';

import { Task } from './task';
import { Layer } from './layer';
import { Project } from './project';
import { Status } from './task_status';

@Injectable()
export class TaskService {
	//URLs for CRUD operations
	allTasksUrl = "http://localhost:8080/user/all-tasks";
	allOngoingTasksUrl = "http://localhost:8080/user/ongoingtasks";
	allOnholdTasksUrl = "http://localhost:8080/user/onholdtasks";
	taskUrl = "http://localhost:8080/user/task"
	allLayersUrl = "http://localhost:8080/user/all-layers";
	allProjectsUrl = "http://localhost:8080/user/all-projects";
	allStatusUrl = "http://localhost:8080/user/all-status";

	//Create constructor to get Http instance
	constructor(private http: Http) {
	}

	//Fetch all status
	getStatus(): Observable<Status[]> {
		return this.http.get(
			this.allStatusUrl).map(this.extractData).catch(this.handleError);
	}

	//Fetch all layers
	getLayers(): Observable<Layer[]> {
		return this.http.get(
			this.allLayersUrl).map(this.extractData).catch(this.handleError);
	}

	//Fetch all projects
	getProjects(): Observable<Project[]> {
		return this.http.get(
			this.allProjectsUrl).map(this.extractData).catch(this.handleError);
	}

	//Fetch all tasks
	getAllTasks(): Observable<Task[]> {
		return this.http.get(
			this.allTasksUrl).map(this.extractData).catch(this.handleError);
	}

	//Fetch all ongoingtasks
	getOngoingTasks(): Observable<Task[]> {
		return this.http.get(
			this.allOngoingTasksUrl).map(this.extractData).catch(this.handleError);
	}

	//Fetch all ongoingtasks
	getOnholdTasks(): Observable<Task[]> {
		return this.http.get(
			this.allOnholdTasksUrl).map(this.extractData).catch(this.handleError);
	}

	//Create task
	public createTask(task: Task): Observable<number> {
		let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
		let options = new RequestOptions({ headers: cpHeaders });
		return this.http.post(this.taskUrl, task, options)
			.map(success => success.status)
			.catch(this.handleError);
	}

	getTaskById(idtask: number): Observable<Task> {

		let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
		let cpParams = new URLSearchParams();
		cpParams.set('idtask', idtask.toString());
		let options = new RequestOptions({ headers: cpHeaders, params: cpParams });
		return this.http.get(this.taskUrl, options)
			.map(this.extractData)
			.catch(this.handleError);
	}

	//Update task
	updateTask(task: Task): Observable<number> {
		let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
		let options = new RequestOptions({ headers: cpHeaders });
		return this.http.put(this.taskUrl, task, options)
			.map(success => success.status)
			.catch(this.handleError);
	}

	//Delete task	
	deleteTaskById(idtask: string): Observable<number> {
		let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
		let cpParams = new URLSearchParams();
		cpParams.set('id', idtask);
		let options = new RequestOptions({ headers: cpHeaders, params: cpParams });
		return this.http.delete(this.taskUrl, options)
			.map(success => success.status)
			.catch(this.handleError);
	}


	//Method to retrieve data
	private extractData(res: Response) {
		let body = res.json();
		return body;
	}

	//Method to handle error
	private handleError(error: Response | any) {
		return Observable.throw(error.status);
	}

}