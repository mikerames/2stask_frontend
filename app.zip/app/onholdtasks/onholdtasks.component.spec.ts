import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnholdtasksComponent } from './onholdtasks.component';

describe('OnholdtasksComponent', () => {
  let component: OnholdtasksComponent;
  let fixture: ComponentFixture<OnholdtasksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnholdtasksComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnholdtasksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
